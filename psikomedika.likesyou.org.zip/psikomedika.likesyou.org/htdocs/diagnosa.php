<?php
include 'koneksi.php';

// Ambil data pasien
$nama = $_POST['nama'];
$jk = $_POST['jk'];
$umur = $_POST['umur'];
$kode_pasien = $_POST['kode_pasien'];
$cf_user = $_POST['cf_user'];

$gejala_dialami = [];
$hasil_diagnosa = [];

// 1. Simpan daftar gejala yang dipilih user (yang nilainya > 0)
$query_gejala = mysqli_query($koneksi, "SELECT * FROM gejala");
$nama_gejala_dict = [];
while($g = mysqli_fetch_array($query_gejala)){
    $nama_gejala_dict[$g['kode']] = $g['nama_gejala'];
    if($cf_user[$g['kode']] > 0){
        $gejala_dialami[] = [
            'kode' => $g['kode'],
            'nama' => $g['nama_gejala'],
            'cf' => $cf_user[$g['kode']]
        ];
    }
}

// 2. Hitung CF untuk SEMUA Penyakit
$query_penyakit = mysqli_query($koneksi, "SELECT * FROM penyakit");
while($p = mysqli_fetch_array($query_penyakit)){
    $kode_p = $p['kode'];
    
    // Ambil rule pakar untuk penyakit ini
    $query_rule = mysqli_query($koneksi, "SELECT * FROM rule WHERE kode_penyakit='$kode_p'");
    
    $cf_he_array = [];
    while($r = mysqli_fetch_array($query_rule)){
        $kode_g = $r['kode_gejala'];
        $cf_pakar = $r['cf_pakar'];
        $cf_u = $cf_user[$kode_g];
        
        // Hitung CF[H,E] = CF_user * CF_pakar (Sesuai Persamaan 2 di Jurnal)
        if($cf_u > 0){
            $cf_he = $cf_pakar * $cf_u;
            $cf_he_array[] = $cf_he;
        }
    }

    // 3. Kalkulasi CF Combine (Sesuai Persamaan 3 & 4 di Jurnal)
    if(count($cf_he_array) > 0){
        $cf_combine = $cf_he_array[0];
        
        for($i = 1; $i < count($cf_he_array); $i++){
            $cf_combine = $cf_combine + ($cf_he_array[$i] * (1 - $cf_combine));
        }
        
        $hasil_diagnosa[] = [
            'kode_penyakit' => $kode_p,
            'nama_penyakit' => $p['nama_penyakit'],
            'solusi' => $p['keterangan'],
            'nilai_cf' => round($cf_combine * 100, 2) // Persentase CF
        ];
    }
}

// Jika tidak ada gejala yang dipilih, cegah error
if(count($hasil_diagnosa) == 0){
    echo "<script>alert('Anda tidak memilih gejala apapun!'); window.location='index.php';</script>";
    exit;
}

// Urutkan hasil dari CF Persentase Tertinggi ke Terendah
usort($hasil_diagnosa, function($a, $b) {
    return $b['nilai_cf'] <=> $a['nilai_cf'];
});

// Ambil Penyakit dengan Persentase Tertinggi
$penyakit_tertinggi = $hasil_diagnosa[0];
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Diagnosa Sistem Pakar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar-custom">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <span class="fw-bold fs-2" style="color: #ffffff;">PsikoMedika</span>
            <span class="badge bg-danger ms-1 align-top">AI</span>
            <span class="text-white ms-2 d-none d-md-inline">||  Skrining Kesehatan Mental</span>
        </div> 
        <a href="index.php" class="btn btn-warning btn-sm fw-bold px-3"> Kembali </a>
    </div>
</div>

<div class="container mt-4">
    <div class="text-center mb-4">
        <h4 class="fw-bold text-secondary">Hasil Diagnosis</h4>
    </div>

    <div class="card-box shadow-sm">
        <div class="header-teal text-center" style="font-size:18px;">Informasi Pasien</div>
        <div class="p-4 text-center text-white" style="background-color: #1aa3b1;">
            <p class="mb-0 fw-bold"><?= htmlspecialchars($nama); ?></p>
            <p class="mb-0">Kode Pasien: <?= $kode_pasien; ?></p>
            <p class="mb-0"><?= $jk; ?>, <?= $umur; ?> Tahun</p>
        </div>
        
        <div class="row g-0">
            <div class="col-md-3 result-box">
                <div class="result-value"><?= count($gejala_dialami); ?></div>
                <div class="result-label">Gejala Dialami</div>
            </div>
            <div class="col-md-4 result-box">
                <div class="result-value text-danger"><?= $penyakit_tertinggi['nilai_cf']; ?>%</div>
                <div class="result-label text-uppercase fw-bold"><?= $penyakit_tertinggi['nama_penyakit']; ?></div>
            </div>
            <div class="col-md-5 result-box text-start">
                <div class="result-label text-center fw-bold mb-2">Solusi</div>
                <p class="mb-0 text-muted" style="font-size: 13px; text-transform: uppercase;">
                    <?= $penyakit_tertinggi['solusi']; ?>
                </p>
            </div>
        </div>
    </div>

<div class="text-center mt-4 mb-5 no-print">
    <a href="index.php" class="btn btn-secondary px-4">Kembali</a>  
    <a href="cetak.php?kode=<?= $kode_pasien; ?>&nama=<?= urlencode($nama); ?>&penyakit=<?= urlencode($penyakit_tertinggi['nama_penyakit']); ?>&cf=<?= $penyakit_tertinggi['nilai_cf']; ?>" target="_blank" class="btn btn-danger px-4 ms-2">
        Cetak PDF </a>
</div>

    <div class="card-box shadow-sm">
        <div class="header-teal">Data Gejala yang Dialami Pasien</div>
        <div class="p-3">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th width="5%" class="text-center">No.</th>
                        <th width="15%">Kode</th>
                        <th width="50%">Gejala</th>
                        <th width="30%">Tingkat Kepastian Pasien (Bobot)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no=1; 
                    foreach($gejala_dialami as $gd){ 
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td><?= $gd['kode']; ?></td>
                        <td><?= $gd['nama']; ?></td>
                        <td><?= $gd['cf']; ?></td>
                    </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
    </div> <footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
        <div class="container">
            <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
        </div>
    </footer>

</body>
</html>