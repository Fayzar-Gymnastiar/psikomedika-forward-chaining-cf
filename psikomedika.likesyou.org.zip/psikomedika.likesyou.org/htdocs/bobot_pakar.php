<?php
session_start();
include 'koneksi.php';

// Cek apakah admin sudah login
if($_SESSION['status'] != 'login') { 
    header("location:login.php"); 
    exit; 
}

// ---------------- PROSES HAPUS DATA ----------------
if(isset($_GET['aksi']) && $_GET['aksi'] == 'hapus'){
    // Mengambil ID dari URL. Di tabel rule, kita menggunakan 'id' (Auto Increment) sebagai penanda unik barisnya.
    $id = $_GET['id'];
    mysqli_query($koneksi, "DELETE FROM rule WHERE id='$id'");
    header("location:bobot_pakar.php");
    exit;
}

// ---------------- PROSES TAMBAH DATA ----------------
if(isset($_POST['tambah'])){
    $kode_penyakit = $_POST['kode_penyakit'];
    $kode_gejala = $_POST['kode_gejala'];
    $cf_pakar = $_POST['cf_pakar'];
    
    // Menyimpan rule baru ke tabel rule
    mysqli_query($koneksi, "INSERT INTO rule (kode_penyakit, kode_gejala, cf_pakar) VALUES ('$kode_penyakit', '$kode_gejala', '$cf_pakar')");
    header("location:bobot_pakar.php");
    exit;
}

// ---------------- PROSES EDIT DATA ----------------
if(isset($_POST['edit'])){
    // ID baris rule yang sedang diedit
    $id = $_POST['id'];
    $kode_penyakit = $_POST['kode_penyakit'];
    $kode_gejala = $_POST['kode_gejala'];
    $cf_pakar = $_POST['cf_pakar'];
    
    // Update data berdasarkan ID rule
    mysqli_query($koneksi, "UPDATE rule SET kode_penyakit='$kode_penyakit', kode_gejala='$kode_gejala', cf_pakar='$cf_pakar' WHERE id='$id'");
    header("location:bobot_pakar.php");
    exit;
}

// ---------------- PERSIAPAN DATA DROPDOWN ----------------
// Kita ambil data penyakit dan gejala dari database dan menyimpannya ke dalam array.
// Tujuannya agar bisa ditampilkan sebagai pilihan (dropdown) di dalam Modal Tambah & Edit.
$list_penyakit = [];
$q_penyakit = mysqli_query($koneksi, "SELECT * FROM penyakit ORDER BY kode ASC");
while($p = mysqli_fetch_array($q_penyakit)) { $list_penyakit[] = $p; }

$list_gejala = [];
$q_gejala = mysqli_query($koneksi, "SELECT * FROM gejala ORDER BY kode ASC");
while($g = mysqli_fetch_array($q_gejala)) { $list_gejala[] = $g; }

?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Rule & Bobot Pakar - Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="navbar-custom"><div class="fw-bold">Manajemen Basis Pengetahuan (Rule CF)</div></div>
<div class="container mt-4 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="admin.php" class="btn btn-secondary">← Kembali</a>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#tambahModal">+ Tambah Rule Pakar</button>
    </div>
    
    <div class="card-box shadow-sm">
        <div class="header-yellow p-2 px-3 text-dark fw-bold" style="background-color: #ffc107; border-radius: 5px 5px 0 0;">Aturan & Bobot Nilai Pakar Sesuai Jurnal</div>
        <div class="p-3 table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-light text-center">
                    <tr>
                        <th width="5%">No</th>
                        <th width="25%">Penyakit</th>
                        <th width="40%">Gejala Terkait</th>
                        <th width="15%">Nilai CF Pakar</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    // Join 3 tabel: Kita tambahkan pengambilan rule.kode_penyakit dan rule.kode_gejala 
                    // agar sistem tahu persis data mana yang harus dipilih saat tombol Edit ditekan
                    $query = mysqli_query($koneksi, "
                        SELECT rule.id, rule.kode_penyakit, rule.kode_gejala, penyakit.nama_penyakit, gejala.nama_gejala, rule.cf_pakar 
                        FROM rule 
                        JOIN penyakit ON rule.kode_penyakit = penyakit.kode 
                        JOIN gejala ON rule.kode_gejala = gejala.kode
                        ORDER BY penyakit.kode ASC, gejala.kode ASC
                    ");
                    while($d = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td class="fw-bold text-secondary"><?= $d['nama_penyakit']; ?></td>
                        <td>[<?= $d['kode_gejala']; ?>] <?= $d['nama_gejala']; ?></td>
                        <td class="text-center fw-bold text-primary"><?= $d['cf_pakar']; ?></td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $d['id']; ?>">Edit</button>
                            <a href="bobot_pakar.php?aksi=hapus&id=<?= $d['id']; ?>" class="btn btn-sm btn-danger text-white" onclick="return confirm('Yakin ingin menghapus Rule CF ini?')">Hapus</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="editModal<?= $d['id']; ?>" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header bg-warning">
                            <h5 class="modal-title fw-bold">Edit Bobot Pakar</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body text-start">
                                <input type="hidden" name="id" value="<?= $d['id']; ?>">
                                
                                <div class="mb-3">
                                    <label class="fw-semibold">Pilih Penyakit</label>
                                    <select name="kode_penyakit" class="form-select" required>
                                        <?php foreach($list_penyakit as $p): ?>
                                            <option value="<?= $p['kode']; ?>" <?= ($p['kode'] == $d['kode_penyakit']) ? 'selected' : ''; ?>>
                                                <?= $p['kode']; ?> - <?= $p['nama_penyakit']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold">Pilih Gejala</label>
                                    <select name="kode_gejala" class="form-select" required>
                                        <?php foreach($list_gejala as $g): ?>
                                            <option value="<?= $g['kode']; ?>" <?= ($g['kode'] == $d['kode_gejala']) ? 'selected' : ''; ?>>
                                                <?= $g['kode']; ?> - <?= $g['nama_gejala']; ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold">Nilai CF Pakar (0.0 - 1.0)</label>
                                    <input type="number" step="0.1" min="0" max="1" name="cf_pakar" class="form-control" value="<?= $d['cf_pakar']; ?>" required>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" name="edit" class="btn btn-warning fw-bold">Simpan Perubahan</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="tambahModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header text-white" style="background-color: #198754;">
        <h5 class="modal-title fw-bold">Tambah Rule & Bobot Baru</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="">
          <div class="modal-body text-start">
            <div class="mb-3">
                <label class="fw-semibold">Pilih Penyakit</label>
                <select name="kode_penyakit" class="form-select" required>
                    <option value="">-- Pilih Penyakit --</option>
                    <?php foreach($list_penyakit as $p): ?>
                        <option value="<?= $p['kode']; ?>"><?= $p['kode']; ?> - <?= $p['nama_penyakit']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="fw-semibold">Pilih Gejala Terkait</label>
                <select name="kode_gejala" class="form-select" required>
                    <option value="">-- Pilih Gejala --</option>
                    <?php foreach($list_gejala as $g): ?>
                        <option value="<?= $g['kode']; ?>"><?= $g['kode']; ?> - <?= $g['nama_gejala']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="fw-semibold">Nilai CF Pakar (0.0 - 1.0)</label>
                <input type="number" step="0.1" min="0" max="1" name="cf_pakar" class="form-control" placeholder="Contoh: 0.8" required>
                <small class="text-muted">Masukkan angka desimal (titik). Contoh: 0.2, 0.4, 0.6, 0.8, atau 1.0</small>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="tambah" class="btn btn-success fw-bold">Simpan Rule</button>
          </div>
      </form>
    </div>
  </div>
</div>

<footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
    <div class="container">
        <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
    </div>
</body>
</html>