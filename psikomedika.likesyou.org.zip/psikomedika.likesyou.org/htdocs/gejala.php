<?php
// Memulai session untuk memastikan admin sudah login
session_start();
include 'koneksi.php';

// Jika admin belum login, kembalikan ke form login
if($_SESSION['status'] != 'login') { 
    header("location:login.php"); 
    exit; 
}

// ---------------- PROSES HAPUS DATA ----------------
// Dijalankan jika ada parameter '?aksi=hapus&kode=...' di URL
if(isset($_GET['aksi']) && $_GET['aksi'] == 'hapus'){
    $kode = $_GET['kode'];
    
    // Menghapus gejala. 
    // Sama seperti penyakit, jika gejala dihapus, rule yang memuat gejala ini akan ikut terhapus otomatis (CASCADE).
    mysqli_query($koneksi, "DELETE FROM gejala WHERE kode='$kode'");
    
    header("location:gejala.php");
    exit;
}

// ---------------- PROSES TAMBAH DATA ----------------
// Dijalankan saat form tambah di-submit
if(isset($_POST['tambah'])){
    $kode = $_POST['kode'];
    $nama_gejala = $_POST['nama_gejala'];
    
    // Menyimpan gejala baru ke database
    mysqli_query($koneksi, "INSERT INTO gejala (kode, nama_gejala) VALUES ('$kode', '$nama_gejala')");
    
    header("location:gejala.php");
    exit;
}

// ---------------- PROSES EDIT DATA ----------------
// Dijalankan saat form edit di-submit
if(isset($_POST['edit'])){
    $kode_lama = $_POST['kode_lama']; // Sebagai acuan WHERE
    $kode = $_POST['kode'];
    $nama_gejala = $_POST['nama_gejala'];
    
    // Memperbarui data gejala
    mysqli_query($koneksi, "UPDATE gejala SET kode='$kode', nama_gejala='$nama_gejala' WHERE kode='$kode_lama'");
    
    header("location:gejala.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Gejala - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar-custom"><div class="fw-bold container">Manajemen Data Gejala</div></div>

<div class="container mt-4 mb-5">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="admin.php" class="btn btn-secondary">← Kembali ke Dashboard</a>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#tambahModal">+ Tambah Gejala</button>
    </div>
    
    <div class="card-box shadow-sm">
        <div class="header-teal p-2 px-3 text-white" style="background-color: #1aa3b1; border-radius: 5px 5px 0 0;">
            Daftar Gejala Mental (K01 - K50)
        </div>
        <div class="p-3 table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-light text-center">
                    <tr>
                        <th width="5%">No</th>
                        <th width="15%">Kode Gejala</th>
                        <th width="60%">Nama Gejala</th>
                        <th width="20%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    $query = mysqli_query($koneksi, "SELECT * FROM gejala ORDER BY kode ASC");
                    while($d = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td class="fw-bold text-center"><?= $d['kode']; ?></td>
                        <td><?= $d['nama_gejala']; ?></td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $d['kode']; ?>">Edit</button>
                            
                            <a href="gejala.php?aksi=hapus&kode=<?= $d['kode']; ?>" 
                               class="btn btn-sm btn-danger text-white" 
                               onclick="return confirm('Yakin ingin menghapus gejala <?= $d['nama_gejala']; ?>?\n\nPeringatan: Rule yang terkait dengan gejala ini juga akan ikut terhapus.')">Hapus</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="editModal<?= $d['kode']; ?>" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header bg-warning">
                            <h5 class="modal-title fw-bold">Edit Data Gejala</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body text-start">
                                <input type="hidden" name="kode_lama" value="<?= $d['kode']; ?>">
                                
                                <div class="mb-3">
                                    <label class="fw-semibold">Kode Gejala</label>
                                    <input type="text" name="kode" class="form-control" value="<?= $d['kode']; ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label class="fw-semibold">Nama Gejala</label>
                                    <input type="text" name="nama_gejala" class="form-control" value="<?= $d['nama_gejala']; ?>" required>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" name="edit" class="btn btn-warning fw-bold">Simpan Perubahan</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="tambahModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header text-white" style="background-color: #198754;">
        <h5 class="modal-title fw-bold">Tambah Gejala Baru</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="">
          <div class="modal-body text-start">
            <div class="mb-3">
                <label class="fw-semibold">Kode Gejala</label>
                <input type="text" name="kode" class="form-control" placeholder="Contoh: K51" required>
            </div>
            <div class="mb-3">
                <label class="fw-semibold">Nama Gejala</label>
                <input type="text" name="nama_gejala" class="form-control" placeholder="Masukkan keluhan / gejala" required>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="tambah" class="btn btn-success fw-bold">Simpan Data</button>
          </div>
      </form>
    </div>
  </div>
</div>
</div> <footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
        <div class="container">
            <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
        </div>
    </footer>

</body>
</html>