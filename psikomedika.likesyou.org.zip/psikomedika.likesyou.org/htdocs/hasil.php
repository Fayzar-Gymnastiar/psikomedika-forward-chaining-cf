<?php
include 'koneksi.php';

$cf_user = $_POST['cf_user'];

$query = mysqli_query($koneksi,"
SELECT * FROM gejala
JOIN rule ON gejala.kode = rule.kode_gejala
WHERE rule.kode_penyakit='P1'
");

$cf = [];

while($d = mysqli_fetch_array($query)){
    $kode = $d['kode'];
    $cf_pakar = $d['cf_pakar'];
    $user = $cf_user[$kode];

    $hasil = $cf_pakar * $user;
    $cf[] = $hasil;
}

$combine = $cf[0];

for($i=1; $i<count($cf); $i++){
    $combine = $combine + ($cf[$i] * (1 - $combine));
}

$persen = $combine * 100;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Hasil Diagnosa</title>
    <link rel="stylesheet"
    href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">

<h2>Hasil Diagnosa</h2>

<div class="alert alert-success">
    <h4>Penyakit: Psycho Soma (Psikosomatik)</h4>
    <h5>Tingkat Keyakinan: <?= round($persen,2); ?>%</h5>
</div>

<a href="index.php" class="btn btn-secondary">Kembali</a>
</div> <footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
        <div class="container">
            <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
        </div>
    </footer>
</body>
</html>