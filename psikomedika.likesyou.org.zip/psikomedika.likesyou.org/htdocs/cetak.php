<?php
// Menerima data dari parameter URL
$kode_pasien = $_GET['kode'];
$nama = $_GET['nama'];
$nama_penyakit = $_GET['penyakit'];
$persentase = $_GET['cf'];
$tanggal = date('d F Y');
$waktu_cetak = date('d/m/y, H.i'); // Menghasilkan format 08/05/26, 19.45
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Cetak Hasil Diagnosa - PsikoMedika AI</title>

<style>
        /* Trik untuk menghilangkan header/footer (URL & Tanggal) bawaan browser otomatis */
        @page {
            size: A4;
            margin: 0; /* Wajib 0 agar teks URL dan waktu bawaan browser mati */
        }

        /* Atur tata letak kertas saat dialog print terbuka */
        @media print {
            body {
                margin: 0;
                padding: 0;
            }
            .container {
                width: 100%;
                max-width: 100%; /* Lepas batas lebar agar menyesuaikan kertas A4 */
                padding: 2cm 2cm 2cm 2cm !important; /* Atas, Kanan, Bawah, Kiri persis 2cm */
                box-sizing: border-box; /* Memastikan padding tidak menambah lebar kertas */
            }
            .btn-print { 
                display: none; /* Sembunyikan tombol cetak */
            }
        }

        /* Tampilan saat dilihat di layar komputer */
        body {
            font-family: 'Times New Roman', Times, serif;
            color: #333;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #fff;
        }

        .container {
            width: 100%;
            max-width: 800px;
            margin: 0 auto;
        }

        /* HEADER KHUSUS CETAK (Kiri: Waktu, Kanan: Judul) */
        .header-cetak-custom {
            display: flex;
            justify-content: space-between;
            font-size: 11px;
            color: #555;
            margin-bottom: 20px;
            border-bottom: 1px solid #eee;
            padding-bottom: 5px;
        }

        /* KOP SURAT */
        .kop-surat {
            text-align: center;
            border-bottom: 3px double #000;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }
        .kop-surat h2 { margin: 0; font-size: 24px; text-transform: uppercase; }
        .kop-surat p { margin: 2px 0; font-size: 14px; }

        /* JUDUL DOKUMEN */
        .judul-surat { text-align: center; margin-bottom: 30px; }
        .judul-surat h4 { margin: 0; text-decoration: underline; }
        .judul-surat p { margin: 0; font-size: 12px; }

        /* KONTEN DAN HASIL */
        .konten { text-align: justify; font-size: 15px; }
        .hasil-box {
            border: 2px solid #333;
            padding: 15px;
            margin: 20px auto;
            text-align: center;
            width: 80%;
            background-color: #f9f9f9;
        }
        .hasil-box h3 { margin: 0; color: #b91c1c; }

        /* FOOTER (Waktu & Tanda Tangan) */
        .footer {
            margin-top: 30px;
            float: right;
            text-align: center;
            width: 250px;
        }

        .qrcode-ttd {
            margin: 10px 0;
        }

        .tanda-tangan {
            margin-top: 5px;
            font-weight: bold;
            text-decoration: underline;
        }
    </style>

</head>
<body onload="window.print()">

    <div class="container">
        
        <div style="text-align: center; margin-bottom: 20px;" class="btn-print">
            <button onclick="window.print()" style="padding: 10px 20px; background: #dc3545; color: white; border: none; cursor: pointer; font-weight: bold; border-radius: 5px;">Cetak / Simpan PDF</button>
        </div>

        <div class="header-cetak-custom">
            <span><?= $waktu_cetak; ?></span>
            <span>Cetak Hasil Diagnosa</span>
        </div>

        <div class="kop-surat">
            <h2>PSIKOMEDIKA AI</h2>
            <p>Layanan Skrining Kesehatan Mental Berbasis <i>Artificial Intelligence</i></p>
            <p>Jl. Mataram No.9, Pesurungan Lor, Kec. Margadana, Kota Tegal, Jawa Tengah 52147 | (0283) 352000 </p>
        </div>

        <div class="judul-surat">
            <h4>SURAT KETERANGAN HASIL DIAGNOSA</h4>
            <p>Nomor: REQ/<?= date('Y/m'); ?>/<?= rand(100, 999); ?></p>
        </div>

        <div class="konten">
            <p>Berdasarkan pemeriksaan yang dilakukan pada hari ini, <strong><?= $tanggal; ?></strong>, melalui aplikasi Sistem Pakar Diagnosa Gangguan Mental dengan menggunakan metode <em>Certainty Factor (CF)</em>, serta berdasarkan pernyataan dan indikasi gejala dari pasien atas nama <strong><?= strtoupper($nama); ?></strong> (Kode: <?= $kode_pasien; ?>), maka sistem menyatakan bahwa pasien tersebut:</p>
            
            <div class="hasil-box">
                <p style="margin-bottom: 5px;">Teridentifikasi Mengalami:</p>
                <h3><?= strtoupper($nama_penyakit); ?></h3>
                <p style="margin-top: 10px; font-size: 14px;">Tingkat Keyakinan Sistem: <strong><?= $persentase; ?>%</strong></p>
            </div>

            <p>Laporan ini dihasilkan secara otomatis oleh sistem sebagai langkah deteksi dini berdasarkan basis pengetahuan yang di-<em>input</em>-kan oleh pakar. Laporan ini bersifat informatif dan sangat disarankan bagi pasien untuk melakukan konsultasi lebih lanjut dengan tenaga medis profesional (Psikolog/Psikiater) guna penanganan yang akurat.</p>
        </div>

        <div class="footer">
            <p>Tegal, <?= $tanggal; ?></p>
            <p>Penanggung Jawab Sistem,</p>
            
            <div class="qrcode-ttd">
                <img src="https://api.qrserver.com/v1/create-qr-code/?size=90x90&data=Terverifikasi+PsikoMedika+AI+ID:<?= $kode_pasien; ?>" alt="QR Code TTD">
            </div>

            <div class="tanda-tangan">
                ADMIN PSIKO MEDIKA AI
            </div>
            <p style="font-size: 10px; font-style: italic; margin-top: 5px;">(Dokumen ini diverifikasi secara elektronik)</p>
        </div>
        
    </div>

</body>
</html>