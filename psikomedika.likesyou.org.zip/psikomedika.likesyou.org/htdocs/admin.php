<?php
session_start();
if($_SESSION['status'] != 'login'){
    header("location:login.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>

<body>
<div class="navbar-custom d-flex justify-content-between align-items-center">
    <div class="logo fw-bold fs-4"> PsikoMedika 
        <span class="badge bg-danger ms-1 align-top">AI</span>
        <span class="badge bg-warning text-dark ms-1">Admin Panel</span>
    </div>
    <div>
        <a href="index.php" class="btn btn-warning btn-sm me-2 fw-bold">Lihat Web</a>
        <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
    </div>
</div>

<div class="container mt-5">
    <h2 class="fw-bold mb-4">Selamat Datang, Admin!</h2>
    <div class="row">
        <div class="col-md-3 mb-3">
            <div class="card p-3 shadow-sm text-center border-0">
                <h5 class="fw-bold text-secondary">Data Penyakit</h5>
                <a href="penyakit.php" class="btn text-white mt-2" style="background-color: #1aa3b1;">Kelola Data</a>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card p-3 shadow-sm text-center border-0">
                <h5 class="fw-bold text-secondary">Data Gejala</h5>
                <a href="gejala.php" class="btn text-white mt-2" style="background-color: #1aa3b1;">Kelola Data</a>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card p-3 shadow-sm text-center border-0">
                <h5 class="fw-bold text-secondary">Bobot Pakar (Rule)</h5>
                <a href="bobot_pakar.php" class="btn text-white mt-2" style="background-color: #1aa3b1;">Kelola Data</a>
            </div>
        </div>
        <div class="col-md-3 mb-3">
            <div class="card p-3 shadow-sm text-center border-0">
                <h5 class="fw-bold text-secondary">Bobot User</h5>
                <a href="bobot_user.php" class="btn text-white mt-2" style="background-color: #1aa3b1;">Lihat Standar</a>
            </div>
        </div>
    </div>
</div>
<footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
    <div class="container">
        <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
    </div>
</footer>
</body>
</html>