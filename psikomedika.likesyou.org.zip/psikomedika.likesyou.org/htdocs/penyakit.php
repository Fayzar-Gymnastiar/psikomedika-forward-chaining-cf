<?php
// Memulai session untuk melacak pengguna yang masuk. 
// Ini wajib ada di baris pertama sebelum ada output HTML apa pun.
session_start();

// Menghubungkan script dengan konfigurasi database di koneksi.php.
include 'koneksi.php';

// SISTEM KEAMANAN: Memeriksa apakah variabel session 'status' berisi 'login'.
// Jika tidak, pengguna akan langsung ditendang kembali ke login.php.
if($_SESSION['status'] != 'login') { 
    header("location:login.php"); 
    exit; // Menghentikan eksekusi script selanjutnya demi keamanan.
}

// ---------------- ALUR PROSES HAPUS DATA (GET) ----------------
// Proses ini dipicu ketika ada parameter 'aksi=hapus' pada URL (biasanya lewat tag <a>).
if(isset($_GET['aksi']) && $_GET['aksi'] == 'hapus'){
    // Mengambil nilai 'kode' dari URL (misal: penyakit.php?aksi=hapus&kode=P1).
    $kode = $_GET['kode'];
    
    // Perintah SQL untuk menghapus baris dari tabel 'penyakit' yang kodenya sesuai.
    // PENTING: Jika database dikonfigurasi dengan 'ON DELETE CASCADE', 
    // data di tabel 'rule' yang menggunakan kode ini akan otomatis ikut terhapus.
    mysqli_query($koneksi, "DELETE FROM penyakit WHERE kode='$kode'");
    
    // Setelah selesai menghapus, segarkan halaman untuk melihat hasilnya.
    header("location:penyakit.php");
    exit;
}

// ---------------- ALUR PROSES TAMBAH DATA (POST) ----------------
// Proses ini dipicu ketika tombol submit dengan name="tambah" di dalam modal diklik.
if(isset($_POST['tambah'])){
    // Menangkap data yang dikirimkan dari input form berdasarkan atribut 'name'.
    $kode = $_POST['kode'];
    $nama = $_POST['nama_penyakit'];
    $keterangan = $_POST['keterangan'];
    
    // Memasukkan data baru ke dalam tabel 'penyakit'.
    mysqli_query($koneksi, "INSERT INTO penyakit (kode, nama_penyakit, keterangan) VALUES ('$kode', '$nama', '$keterangan')");
    
    // Kembali ke halaman utama manajemen untuk memperbarui daftar.
    header("location:penyakit.php");
    exit;
}

// ---------------- ALUR PROSES EDIT DATA (POST) ----------------
// Proses ini dipicu ketika tombol submit dengan name="edit" di dalam modal edit diklik.
if(isset($_POST['edit'])){
    // kode_lama digunakan sebagai referensi di klausa WHERE jika kode utamanya juga ingin diubah.
    $kode_lama = $_POST['kode_lama'];
    $kode = $_POST['kode'];
    $nama = $_POST['nama_penyakit'];
    $keterangan = $_POST['keterangan'];
    
    // Memperbarui data yang sudah ada berdasarkan identitas kode lamanya.
    mysqli_query($koneksi, "UPDATE penyakit SET kode='$kode', nama_penyakit='$nama', keterangan='$keterangan' WHERE kode='$kode_lama'");
    
    header("location:penyakit.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Data Penyakit - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar-custom">
    <div class="fw-bold container">Manajemen Data Penyakit</div>
</div>

<div class="container mt-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <a href="admin.php" class="btn btn-secondary">← Kembali ke Dashboard</a>
        <button class="btn btn-success" data-bs-toggle="modal" data-bs-target="#tambahModal">+ Tambah Penyakit</button>
    </div>
    
    <div class="card-box shadow-sm">
        <div class="header-teal p-2 px-3 text-white" style="background-color: #1aa3b1; border-radius: 5px 5px 0 0;">
            Daftar Penyakit & Solusi Terdaftar
        </div>
        <div class="p-3 table-responsive">
            <table class="table table-bordered table-hover align-middle">
                <thead class="table-light text-center">
                    <tr>
                        <th width="5%">No</th>
                        <th width="10%">Kode</th>
                        <th width="25%">Nama Penyakit</th>
                        <th width="45%">Keterangan / Solusi Penanganan</th>
                        <th width="15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $no = 1;
                    // Mengambil semua data dari tabel penyakit dan diurutkan secara alfabetis berdasarkan kodenya.
                    $query = mysqli_query($koneksi, "SELECT * FROM penyakit ORDER BY kode ASC");
                    
                    // Melakukan perulangan (looping) untuk setiap baris data yang ditemukan di database.
                    while($d = mysqli_fetch_array($query)){
                    ?>
                    <tr>
                        <td class="text-center"><?= $no++; ?></td>
                        <td class="fw-bold text-center"><?= $d['kode']; ?></td>
                        <td><?= $d['nama_penyakit']; ?></td>
                        <td><small><?= $d['keterangan']; ?></small></td>
                        <td class="text-center">
                            <button class="btn btn-sm btn-warning" data-bs-toggle="modal" data-bs-target="#editModal<?= $d['kode']; ?>">Edit</button>
                            
                            <a href="penyakit.php?aksi=hapus&kode=<?= $d['kode']; ?>" 
                               class="btn btn-sm btn-danger text-white" 
                               onclick="return confirm('Yakin ingin menghapus data ini?')">Hapus</a>
                        </td>
                    </tr>

                    <div class="modal fade" id="editModal<?= $d['kode']; ?>" tabindex="-1">
                      <div class="modal-dialog">
                        <div class="modal-content">
                          <div class="modal-header bg-warning">
                            <h5 class="modal-title fw-bold">Perbarui Data: <?= $d['kode']; ?></h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                          </div>
                          <form method="POST" action="">
                              <div class="modal-body">
                                <input type="hidden" name="kode_lama" value="<?= $d['kode']; ?>">
                                
                                <div class="mb-3 text-start">
                                    <label class="fw-semibold">Kode Penyakit</label>
                                    <input type="text" name="kode" class="form-control" value="<?= $d['kode']; ?>" required>
                                </div>
                                <div class="mb-3 text-start">
                                    <label class="fw-semibold">Nama Penyakit</label>
                                    <input type="text" name="nama_penyakit" class="form-control" value="<?= $d['nama_penyakit']; ?>" required>
                                </div>
                                <div class="mb-3 text-start">
                                    <label class="fw-semibold">Keterangan / Solusi</label>
                                    <textarea name="keterangan" class="form-control" rows="4" required><?= $d['keterangan']; ?></textarea>
                                </div>
                              </div>
                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                <button type="submit" name="edit" class="btn btn-warning fw-bold">Simpan Perubahan</button>
                              </div>
                          </form>
                        </div>
                      </div>
                    </div>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="modal fade" id="tambahModal" tabindex="-1">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header text-white" style="background-color: #198754;">
        <h5 class="modal-title fw-bold">Tambah Penyakit Baru</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <form method="POST" action="">
          <div class="modal-body">
            <div class="mb-3">
                <label class="fw-semibold">Kode Penyakit</label>
                <input type="text" name="kode" class="form-control" placeholder="Contoh: P8" required>
            </div>
            <div class="mb-3">
                <label class="fw-semibold">Nama Penyakit</label>
                <input type="text" name="nama_penyakit" class="form-control" placeholder="Masukkan nama penyakit" required>
            </div>
            <div class="mb-3">
                <label class="fw-semibold">Keterangan / Solusi</label>
                <textarea name="keterangan" class="form-control" rows="4" placeholder="Masukkan detail solusi penanganan..." required></textarea>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
            <button type="submit" name="tambah" class="btn btn-success fw-bold">Simpan Data</button>
          </div>
      </form>
    </div>
  </div>
</div>
    </div> <footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
        <div class="container">
            <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
        </div>
    </footer>
</body>
</html>