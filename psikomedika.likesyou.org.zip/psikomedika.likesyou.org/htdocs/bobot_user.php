<?php
// Memulai session untuk memastikan hanya admin yang bisa mengakses halaman ini
session_start();

// Keamanan: Jika status session bukan 'login', tendang kembali ke halaman login
if($_SESSION['status'] != 'login') { 
    header("location:login.php"); 
    exit; 
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Skala Bobot User - Admin Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="navbar-custom">
    <div class="fw-bold container">Informasi Skala Bobot User</div>
</div>

<div class="container mt-4 mb-5">
    <div class="mb-3">
        <a href="admin.php" class="btn btn-secondary">← Kembali ke Dashboard</a>
    </div>
    
    <div class="card-box shadow-sm border-0">
        <div class="header-teal p-3 text-white rounded-top" style="background-color: #1aa3b1;">
            <h5 class="mb-0 fw-bold">Skala Nilai Certainty Factor Pengguna (User)</h5>
        </div>
        
        <div class="p-4">
            <div class="alert alert-info border-0 rounded-3 shadow-sm mb-4" style="background-color: #e9f7f9; color: #0c5460;">
                <strong>Informasi:</strong> Nilai di bawah ini merupakan standar pilihan tingkat keyakinan yang disajikan kepada pasien saat mengisi form diagnosa. [cite_start] Data ini mengacu pada penetapan pakar di Jurnal (Tabel 1)[cite: 128]. Nilai ini tertanam langsung (*hardcoded*) pada sistem antarmuka pengguna (`index.php`) dan menjadi faktor pengali utama terhadap nilai CF Pakar.
            </div>
            
            <div class="table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light text-center">
                        <tr>
                            <th width="10%">No</th>
                            <th width="60%">Tingkat Kepastian (Keterangan)</th>
                            <th width="30%">Nilai Bobot (CF User)</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td class="text-center">1</td>
                            <td>Tidak Tahu / Tidak Mengalami</td>
                            <td class="text-center fw-bold text-danger">0.0</td>
                        </tr>
                        <tr>
                            <td class="text-center">2</td>
                            <td>Tidak Tahu (Sedikit Ragu)</td>
                            <td class="text-center fw-bold text-primary">0.2</td>
                        </tr>
                        <tr>
                            <td class="text-center">3</td>
                            <td>Mungkin</td>
                            <td class="text-center fw-bold text-primary">0.4</td>
                        </tr>
                        <tr>
                            <td class="text-center">4</td>
                            <td>Kemungkinan Besar</td>
                            <td class="text-center fw-bold text-primary">0.6</td>
                        </tr>
                        <tr>
                            <td class="text-center">5</td>
                            <td>Hampir Pasti</td>
                            <td class="text-center fw-bold text-primary">0.8</td>
                        </tr>
                        <tr>
                            <td class="text-center">6</td>
                            <td>Pasti</td>
                            <td class="text-center fw-bold text-success">1.0</td>
                        </tr>
                    </tbody>
                </table>
            </div>
            
            <div class="mt-3 text-muted" style="font-size: 14px;">
                <em>* Catatan: Jika pengguna memilih nilai "0.0", sistem algoritma otomatis akan mengabaikan gejala tersebut dalam perhitungan CF Combine.</em>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

<footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
    <div class="container">
        <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
    </div>
</body>
</html>