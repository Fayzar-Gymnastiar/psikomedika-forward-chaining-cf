<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html>
<head>
    <title>Sistem Pakar : Forward Chaining & Certainty Factor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
    <link rel="manifest" href="/manifest.json">
    <meta name="theme-color" content="#ffca28">
</head>
<body>

<div class="navbar-custom">
    <div class="container d-flex justify-content-between align-items-center">
        <div>
            <span class="fw-bold fs-2" style="color: #ffffff;">PsikoMedika</span>
            <span class="badge bg-danger ms-1 align-top">AI</span>
            <span class="text-white ms-2 d-none d-md-inline">||  Skrining Kesehatan Mental</span>
        </div>
        
        <a href="login.php" class="btn btn-warning btn-sm fw-bold px-3">
            Login Admin </a>
    </div>
</div>

<div class="container mt-4">
    <form action="diagnosa.php" method="POST">
        
        <div class="card-box">
            <div class="header-teal">Informasi Pasien</div>
            <div class="p-4">
                <div class="row mb-3 align-items-center">
                    <label class="col-sm-2 col-form-label fw-semibold">Kode Assessment</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" value="<?= 'AP-'.rand(1000,9999); ?>" readonly name="kode_pasien">
                    </div>
                </div>
                <div class="row mb-3 align-items-center">
                    <label class="col-sm-2 col-form-label fw-semibold">Nama</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" name="nama" required>
                    </div>
                </div>
                <div class="row mb-3 align-items-center">
                    <label class="col-sm-2 col-form-label fw-semibold">Jenis Kelamin</label>
                    <div class="col-sm-4">
                        <select class="form-select" name="jk" required>
                            <option value="Pria">Pria</option>
                            <option value="Wanita">Wanita</option>
                        </select>
                    </div>
                    <label class="col-sm-2 col-form-label text-center fw-semibold">Umur</label>
                    <div class="col-sm-3 d-flex align-items-center">
                        <input type="number" class="form-control me-2" name="umur" required> Tahun
                    </div>
                </div>
            </div>
        </div>

        <div class="card-box">
            <div class="header-yellow">Pilih Gejala yang Dirasakan / Dialami oleh Pasien</div>
            <div class="p-3">
                <table class="table table-hover table-gejala align-middle">
                    <thead>
                        <tr>
                            <th width="5%" class="text-center">No.</th>
                            <th width="65%">Gejala</th>
                            <th width="30%">Tingkat Kepastian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $no = 1;
                        $query = mysqli_query($koneksi, "SELECT * FROM gejala");
                        while($data = mysqli_fetch_array($query)){
                        ?>
                        <tr>
                            <td class="text-center"><?= $no++; ?></td>
                            <td><?= $data['nama_gejala']; ?></td>
                            <td>
                                <select name="cf_user[<?= $data['kode']; ?>]" class="form-select">
                                    <option value="0">Tidak Tahu / Tidak Mengalami</option>
                                    <option value="0.2">Tidak Tahu (Sedikit Ragu)</option>
                                    <option value="0.4">Mungkin</option>
                                    <option value="0.6">Kemungkinan Besar</option>
                                    <option value="0.8">Hampir Pasti</option>
                                    <option value="1">Pasti</option>
                                </select>
                            </td>
                        </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <div class="text-end mt-4 mb-2">
                    <button type="submit" class="btn btn-primary px-5 py-2 fw-bold" style="background-color: #1aa3b1; border:none;">DIAGNOSA</button>
                </div>
            </div>
        </div>
    </form>
</div>

    <footer class="text-center py-3 mt-5 w-100 shadow-sm" style="background-color: #46555f; color: #ffffff;">
        <div class="container">
            <small class="fw-semibold">© 2026 UniversitasHarkatNegeri | Dibuat Untuk Projek UAS</small>
        </div>
    </footer>
    
    <script>
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
      navigator.serviceWorker.register('/sw.js').then(function(registration) {
        console.log('ServiceWorker registration successful with scope: ', registration.scope);
      }, function(err) {
        console.log('ServiceWorker registration failed: ', err);
      });
    });
  }
</script>
    
</body>
</html>