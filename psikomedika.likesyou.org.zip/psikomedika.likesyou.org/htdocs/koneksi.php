<?php
// Konfigurasi Koneksi Database InfinityFree

$host       = "sql306.infinityfree.com";            // Sesuai dengan MYSQL HOSTNAME di panel
$username   = "if0_41347472";                       // Sesuai dengan MYSQL USERNAME di panel
$password   = "ejHmUS9JftphFg";        // Ganti dengan teks password aslimu
$database   = "if0_41347472_db_sistem_pakar";       // Sesuai dengan DATABASE NAME di panel

$koneksi = mysqli_connect($host, $username, $password, $database);

if(!$koneksi){
    die("Koneksi gagal : " . mysqli_connect_error());
}
?>