<?php
session_start();
include 'koneksi.php';

if(isset($_SESSION['status']) && $_SESSION['status'] == 'login'){
    header("location:admin.php");
    exit;
}

if(isset($_POST['login'])){
    $username = mysqli_real_escape_string($koneksi, $_POST['username']);
    $password = mysqli_real_escape_string($koneksi, $_POST['password']);

    // Cek data di tabel admin
    $query = mysqli_query($koneksi, "SELECT * FROM admin WHERE username='$username' AND password='$password'");
    
    if(mysqli_num_rows($query) > 0) {
        $_SESSION['status'] = 'login';
        header("location:admin.php");
    } else {
        $error = "Username atau Password salah!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login Admin - Sistem Pakar</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="style.css">
</head>
<body class="d-flex align-items-center py-4 bg-body-tertiary" style="height: 100vh;">
<main class="form-signin w-100 m-auto" style="max-width: 400px;">
    <div class="card border-0 shadow rounded-4 p-4">
        <h2 class="fw-bold text-center mb-4">Login Admin</h2>
        <?php if(isset($error)): ?>
            <div class="alert alert-danger text-center"><?= $error; ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-floating mb-3">
                <input type="text" class="form-control" id="username" name="username" required placeholder="Username">
                <label for="username">Username</label>
            </div>
            <div class="form-floating mb-4">
                <input type="password" class="form-control" id="password" name="password" required placeholder="Password">
                <label for="password">Password</label>
            </div>
            <button class="btn w-100 py-2 text-white fw-bold" style="background-color: #1aa3b1;" type="submit" name="login">Sign in</button>
            <div class="text-center mt-3">
                <a href="index.php" class="text-decoration-none">Kembali ke Halaman Utama</a>
            </div>
        </form>
    </div>
</main>
</div> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>